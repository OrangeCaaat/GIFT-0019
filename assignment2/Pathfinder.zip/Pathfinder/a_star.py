# writing your code here

def a_star(start, end):
    return None